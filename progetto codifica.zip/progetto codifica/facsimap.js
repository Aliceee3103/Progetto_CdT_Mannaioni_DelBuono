// facsimap.js
(function () {
  // collezione di immagini già gestite
  const imgs = new Set();

  function parseCoords(str) {
    return String(str).split(',').map(n => parseFloat(n));
  }

  // Ridimensiona le aree cliccabiliin base alle dimensioni attuali dell'immagine
  function scaleAreas(img) {

    // Ottiene il nome della mappa collegata all'immagine 
    const mapName = img.useMap ? img.useMap.replace('#', '') : null;
    if (!mapName) return;
    const map = document.querySelector(`map[name="${mapName}"]`);
    if (!map) return;  // se la mappa non esiste, esce

    // dimensioni naturali
    const naturalW = parseFloat(img.getAttribute('data-natural-width')) || img.naturalWidth || img.clientWidth;
    const naturalH = parseFloat(img.getAttribute('data-natural-height')) || img.naturalHeight || img.clientHeight;

    // Dimensioni effettive dell'immagine visualizzata nel browser
    const w = img.clientWidth;
    // L'altezza se non è disponibile, viene calcolata mantenendo le proporzioni
    const h = img.clientHeight || (w * (naturalH / naturalW));
    // Se manca una delle misure, non può fare la scalatura, esce
    if (!naturalW || !naturalH || !w || !h) return;

     // scala orizzontale e scala verticale
    const sx = w / naturalW;
    const sy = h / naturalH;

    map.querySelectorAll('area').forEach(area => {
      
    // Alla prima esecuzione vengono salvate le coordinate originali, così future scalature non accumulano errori
      if (!area.dataset.ox) {
        const orig = parseCoords(area.coords);
        area.dataset.ox = JSON.stringify(orig);
      }
      const orig = JSON.parse(area.dataset.ox);
      const scaled = orig.map((v, i) => Math.round((i % 2 === 0 ? v * sx : v * sy)));
      area.coords = scaled.join(',');
      area.style.cursor = 'pointer';
    });
  }

    // Riesegue la scalatura di tutte le immagini registrate
  function rescaleAll() {
    imgs.forEach(scaleAreas);
  }

    // Inizializza una singola <map> e la collega alla sua immagine
  function setupOneMap(mapEl) {
    if (!mapEl || mapEl.dataset.bound) return; // già inizializzata
    mapEl.dataset.bound = '1';

       // Trova l’immagine che usa quella determinata mappa
    const name = mapEl.getAttribute('name');
    const img = document.querySelector(`img[usemap="#${name}"]`);
    if (!img) return;

      // Aggiunge l’immagine alla lista di quelle da riscalare
    imgs.add(img);
    // scala una prima volta 
    scaleAreas(img);

    // Gestisce il click sulle aree cliccabili della mappa
    mapEl.addEventListener('click', (ev) => {
      const area = ev.target.closest('area[href^="#"]');
      if (!area) return;
      const id = area.getAttribute('href').slice(1);
      const target = document.getElementById(id);
      if (!target) return;
      ev.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      target.classList.add('hit-highlight');
      setTimeout(() => target.classList.remove('hit-highlight'), 2000);
      // aggiorna hash
      location.hash = id;
    }, { passive: false });
  }

  // Usato per evitare troppi ricalcoli durante resize
  let rid;
  function onResize() {
    cancelAnimationFrame(rid);
    rid = requestAnimationFrame(rescaleAll);
  }

    // Gestisce i bottoni "Mostra immagini"
  function initButtons() {
    document.querySelectorAll('.btn-toggle-immagini').forEach(btn => {
      const box = btn.nextElementSibling; 
      if (!box) return;

      btn.addEventListener('click', () => {

          // Stato attuale del bottone
        const open = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', String(!open));

        // Mostra/nasconde la sezione immagini usando l’attributo native "hidden"
        box.hidden = open;

        // quando diventa visibile, registra mappe e riscalale dopo il layout
        if (!box.hidden) {
          requestAnimationFrame(() => {
            box.querySelectorAll('map').forEach(setupOneMap);
            rescaleAll();
          });
        }
      });
    });
  }

  function initMaps() {

      // Inizializza tutte le mappe <map> già presenti sulla pagina
    document.querySelectorAll('map').forEach(setupOneMap);
    // piccola attesa per permettere il layout iniziale
    setTimeout(rescaleAll, 200);
  }

  function init() {
    initButtons();
    initMaps();
    window.addEventListener('resize', onResize);
  }

  // Controlla se il DOM è già pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

document.addEventListener("DOMContentLoaded", function () {
  const bottoni = document.querySelectorAll("#bottoni button");
  const pulisci = document.getElementById("pulisci-tutto");

  // Gestione dei filtri (tutti i bottoni tranne "pulisci")
  bottoni.forEach(bottone => {
    if (bottone === pulisci) return;

    bottone.addEventListener("click", () => {
      const classe = bottone.id; 
      bottone.classList.toggle("attivo");

      if (classe === "regularized") {
        document.querySelectorAll(".regolarizzazioni-group").forEach(gruppo => {
          gruppo.classList.toggle("regolarizzazioni-attiva");
        });
      } else if (classe === "corrected") {
        document.querySelectorAll(".correzioni-group").forEach(gruppo => {
          gruppo.classList.toggle("correzioni-attiva");
        });
      } else {
        // evidenziazione generica
        document.querySelectorAll(`.${CSS.escape(classe)}`).forEach(elem => {
          elem.classList.toggle(`evidenzia-${classe}`);
        });
      }
    });
  });

  // Pulisci tutto
  if (pulisci) {
    pulisci.addEventListener("click", () => {
      bottoni.forEach(b => b.classList.remove("attivo"));

      // spegne correzioni/regolarizzazioni
      document.querySelectorAll(".correzioni-group").forEach(g => g.classList.remove("correzioni-attiva"));
      document.querySelectorAll(".regolarizzazioni-group").forEach(g => g.classList.remove("regolarizzazioni-attiva"));

      document.querySelectorAll("[class*='evidenzia-']").forEach(el => {
        el.className = el.className
          .split(/\s+/)
          .filter(c => !c.startsWith("evidenzia-"))
          .join(" ");
      });
    });
  }
});

// Gestisce l’apertura e la chiusura dei menu, quando si clicca un pulsante mostra il contenuto corrispondente e nasconde tutti gli altri.
document.addEventListener('DOMContentLoaded', function () {
  const buttons = document.querySelectorAll('.main_menu_item');
  const popups = document.querySelectorAll('.menu_content');

  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const id = button.getAttribute('data-id');

      popups.forEach(p => {
        if (p.id === id) {
          p.classList.toggle('menu_content_hide');
        } else {
          p.classList.add('menu_content_hide');
        }
      });
    });
  });
});


